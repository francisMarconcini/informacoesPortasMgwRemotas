<?php
class apgs extends CI_Model {

   function __construct(){
      parent::__construct();
   }
   
   
   function confApgs(){
       $query = $this->db->query('select * from apgsportas_tb');
       	   
		return $query->result();
   }
}
?>