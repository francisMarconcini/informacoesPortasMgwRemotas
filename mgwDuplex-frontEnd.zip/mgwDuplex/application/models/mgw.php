<?php
class mgw extends CI_Model {

   function __construct(){
      parent::__construct();
   }
   
   
   function confEth(){
       $query = $this->db->query("select mgwportas_tb.mgw,data,subrack,slot,gbEth,ethernetspeedduplex_tb.status as speedAtualPort,admstate_tb.status as admStatePort,autoNeg,
	   ethernetspeedduplex_tb.status as speedConfPort,errorsLinkIn,errorsLinkOut,discardsLinkIn,discardsLinkOut,macaddr,mgw_tb.UF as ufMgw
	   from mgwportas_tb, admstate_tb,ethernetspeedduplex_tb,mgw_tb WHERE mgwportas_tb.admState = admstate_tb.value and mgwportas_tb.speedConf = ethernetspeedduplex_tb.value 
	   and mgwportas_tb.speedAtual = ethernetspeedduplex_tb.value and mgwportas_tb.mgw = mgw_tb.MGW");
       	   
		return $query->result();
   }
}
?>