<?php
class garps extends CI_Model {

   function __construct(){
      parent::__construct();
   }
   
   
   function confgarps(){
       $query = $this->db->query("select garp_tb.MGC,garp_tb.DATA,garp_tb.RP,garp_tb.INTERFACE,garp_tb.ADMSTATE,garp_tb.OPERSTATE,garp_tb.MAC,garp_tb.INTERFACESPEED,
	   garp_tb.DUPLEXSTATUS,garp_tb.CRCERRORS,garp_tb.MAXFRAMELENGTHERRORS,garp_tb.SHORTFRAMEERRORS,garp_tb.OVERRUNERRORS,garp_tb.LATECOLLISIONERRORS,
	   garp_tb.EXCESSIVECOLLISIONERRORS,garp_tb.UNDERRUNERRORS,exemp_tb.resource 
	    from garp_tb, exemp_tb WHERE garp_tb.mgc = exemp_tb.MGC and exemp_tb.rp = garp_tb.RP and resource not like '%GCPH-%' ");
       	   
		return $query->result();
   }
}
?>