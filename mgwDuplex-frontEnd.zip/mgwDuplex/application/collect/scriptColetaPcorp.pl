use 5.010;
use strict;
use warnings;
use Shell;
use Time::Piece;
use DateTime;
use File::Copy;
use File::Path;
use DBI;
use Net::Telnet;
use File::Basename qw(dirname);
use Cwd  qw(abs_path);
use lib dirname(dirname abs_path $0) . '/lib'; 
use My::Processa qw(verifica);


my $sh = Shell->new;
my $data ;
my $arquivo;
my $dbh;
my @data;
my $telnet;
my $output;
my $num_linha = 0;
my $buffer="";
my @dados;
my $erro;
my $cont = 0;

system("del softwareCorrections.txt");
system("del hardwareApgApz.txt");

$dbh = DBI->connect("dbi:mysql:mgc_db:localhost:3306","root","") or die "Unable to connect: $DBI::errstr\n"; 



my $instrucao_sql = "SELECT * FROM mgc_tb"; 
my $meu_recordset = $dbh->prepare($instrucao_sql); 
$meu_recordset->execute(); 

while (@data = $meu_recordset->fetchrow_array()) {
           
            $telnet = new Net::Telnet (Timeout => 20,
                                #Dump_Log   => "dump\\".$data[1].".log",
                                Input_Log => $data[1].".log",
						#        Input_Log => "MGCCPSC.log",
                                Output_log => "output\\".$data[1].".log",
						#        Output_log => "output\\MBCBFEC.log",
                                Prompt => '/\$ $/') or die "Could not make connection.---".$telnet->errmsg;

$telnet->max_buffer_length(50*1024*1024);        
  
$telnet->open('10.234.38.35');
$telnet->waitfor(Match => '/login: /i', Errmode => 'return', Timeout => '30');
$telnet->print('rj279240');
$telnet->waitfor(Match => '/password: $/i', Errmode => 'return', Timeout => '30');
$telnet->print('KF@17fra');
$telnet->waitfor(Match => '/>/i', Errmode => 'return', Timeout => '30');
$telnet->print('eaw '.$data[1]);
#$telnet->print('eaw MGCCPSC');
$telnet->waitfor(Match => '/</i', Errmode => 'return', Timeout => '30');
$erro  = $telnet->errmsg;
print "tamanho da string do erro: ".length($erro);
if(length($erro) > 2){
	$telnet->waitfor(Match => '/>/i', Errmode => 'return', Timeout => '30');
    $telnet->print('exit'); 
	$telnet->close;
}
else{
$telnet->print('pcorp:block=all;');
$telnet->waitfor(Match =>'/</i', Errmode => 'return', Timeout => '30');          
$telnet->print('saosp;');
$telnet->waitfor(Match =>'/</i', Errmode => 'return', Timeout => '30');          
print $telnet->errmsg;
$telnet->print('aploc;');
$telnet->waitfor(Match => '/>/i', Errmode => 'return', Timeout => '30');
$telnet->print('swrprint');
$telnet->waitfor(Match => '/>/i', Errmode => 'return', Timeout => '30');
$telnet->print('exit');
$telnet->waitfor(Match => '/</i', Errmode => 'return', Timeout => '30');          
$telnet->print('exit;');
print $telnet->errmsg;
$telnet->waitfor(Match => '/>/i', Errmode => 'return', Timeout => '30');
$telnet->print('exit');
$telnet->close;
system("gawk -f gawkParser.awk.txt ".$data[1].".log");
#system("gawk -f gawkParser.awk.txt MGCCPSC.log");
if($data[7])
	{
		coletaSpx($data[1]);
	}
   }
}
#coletaSpx('MBCBFEC');

$meu_recordset->finish; 
$dbh->disconnect; 

sub coletaSpx{
	
	my ($bladeSpx) = @_;
	
	telnetSpx($bladeSpx,'cp1');
	telnetSpx($bladeSpx,'cp2');
	

}

sub telnetSpx{

use Net::Telnet;

my ($spx,$cp) = @_;

$telnet = new Net::Telnet (Timeout => 20,
                                #Dump_Log   => "dump\\".$data[1].".log",
                                Input_Log => $spx.$cp.".log",
                                Output_log => "output\\".$spx.$cp.".log",
                                Prompt => '/\$ $/') or die "Could not make connection.---".$telnet->errmsg;

$telnet->max_buffer_length(50*1024*1024);        
  
$telnet->open('10.234.38.35');
$telnet->waitfor(Match => '/login: /i', Errmode => 'return', Timeout => '30');
$telnet->print('rj279240');
$telnet->waitfor(Match => '/password: $/i', Errmode => 'return', Timeout => '30');
$telnet->print('KF@17fra');
$telnet->waitfor(Match => '/>/i', Errmode => 'return', Timeout => '30');
$telnet->print('eaw '.$spx);
$telnet->waitfor(Match => '/</i', Errmode => 'return', Timeout => '30');
$telnet->print('aploc;');
$telnet->waitfor(Match => '/>/i', Errmode => 'return', Timeout => '30');
$telnet->print('swrprint');
$telnet->waitfor(Match => '/>/i', Errmode => 'return', Timeout => '30');
$telnet->print('mml -cp '.$cp);
$telnet->waitfor(Match => '/</i', Errmode => 'return', Timeout => '30');
$telnet->print('saosp;');
$telnet->waitfor(Match => '/</i', Errmode => 'return', Timeout => '30');
$telnet->print('pcorp:block=all;');
$telnet->waitfor(Match => '/</i', Errmode => 'return', Timeout => '30');
$telnet->print('exit;');      
$telnet->waitfor(Match => '/>/i', Errmode => 'return', Timeout => '30');
$telnet->print('exit');    
print $telnet->errmsg;          
$telnet->close;
system("gawk -f gawkParser.awk.txt ".$spx.$cp.".log");

}








