use mgc_db;
delete from pcorp_tb;
load data local infile 'C:\\wamp\\www\\softwareCompApz\\application\\collect\\softwareCorrections.txt' into table pcorp_tb fields terminated by ',';