<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="pt">
<head>
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
<!-- Latest compiled and minified CSS -->
<link href="<?php echo base_url();?>includes/bootstrap/css/bootstrap.min.css" rel="stylesheet">
 
<!-- Latest compiled and minified JavaScript -->
<script src="<?php echo base_url();?>includes/bootstrap/js/bootstrap.min.js"></script>
<script src="<?php echo base_url();?>includes/jquery.quicksearch.js" type="text/javascript"></script>

<script language="JavaScript" type="text/JavaScript">
 
    $(document).ready(function(){
        $('input#id_search').quicksearch('table#apgsTable tbody tr');
    });
 
</script>

	<meta charset="utf-8">
	<title>GB ETHERNET MGW ERICSSON</title>
</head>

<body>
<div class="container">
<h2>ETMFG/ETIPG Configuration - RDAAC04</h2>
</div>
<div class="container">
 <p align="right"><input name="search" id="id_search" autofocus="" type="text"><img src="<?php echo base_url();?>includes/pictures/search.png"/></p><br>
 <table id="apgsTable" class="table table-hover">
	<thead class="thead-inverse"><tr><th align="center"><b>MGW</b></th><th align="center"><b>DATA</b></th><th align="center"><b>SUBRACK</b></th><th align="center"><b>SLOT</b></th><th align="center"><b>GB ETHERNET</b></th><th align="center"><b>SPEED ATUAL</b></th><th align="center"><b>ADM STATUS</b></th><th align="center"><b>AUTO-NEGOTIATION</b></th><th align="center"><b>SPEED CONFIGURED</b></th><th align="center"><b>ERRORS LINK IN</b></th><th align="center"><b>ERRORS LINK OUT</b></th><th align="center"><b>DISCARDS LINK IN</b></th><th align="center"><b>DISCARDS LINK OUT</b></th><th align="center"><b>MACADDR</b></th><th align="center"><b>UF</b></t</tr></thead>
	<tbody>
 <?php

foreach ($mgws as $mgw):
	
			echo "<tr><td align=center>".$mgw->mgw."</td><td align=center>".$mgw->data."</td><td align=center>".$mgw->subrack."</td><td align=center>".$mgw->slot."</td><td align=center>".$mgw->gbEth."</td><td align=center>".$mgw->speedAtualPort."</td><td align=center>".$mgw->admStatePort."</td><td align=center>".$mgw->autoNeg."</td><td align=center>".$mgw->speedConfPort."</td><td align=center>".$mgw->errorsLinkIn."</td><td align=center>".$mgw->errorsLinkOut."</td><td align=center>".$mgw->discardsLinkIn."</td><td align=center>".$mgw->discardsLinkOut."</td><td align=center>".$mgw->macaddr."</td><td align=center>".$mgw->ufMgw."</td></tr>";
		
endforeach;

  
?>	
</tbody>
<tfoot>
</tfoot>
</table>

</body>
</html>